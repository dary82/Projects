#include "Tests.h"
#include "Task.h"
#include "DynamicVector.h"
#include "Repository.h"
#include "Service.h"
#include "UI.h"
#include <assert.h>

void Task_ValidInput_TitleIsGood()
{
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	assert(task1.getTitle() == "clean");
}

void Task_ValidInput_TypeIsGood()
{
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	assert(task1.getType() == "spilled");
}

void GetDay_ValidInput_IsGood()
{
	Date lastPerformed{ 03, 21, 1245 };
	assert(lastPerformed.getDay() == 21);
}

void GetMonth_ValidInput_IsGood()
{
	Date lastPerformed{ 03, 21, 1245 };
	assert(lastPerformed.getMonth() == 3);
}

void GetYear_ValidInput_IsGood()
{
	Date lastPerformed{ 03, 21, 1245 };
	assert(lastPerformed.getYear() == 1245);
}

void Task_ValidInput_LastPerformedIsGood()
{
	Date lastPerformed{ 03, 21, 1245 };
	Task task1{ "clean", "spilled", lastPerformed, 4, "sparkling" };
	GetDay_ValidInput_IsGood();
	GetMonth_ValidInput_IsGood();
	GetYear_ValidInput_IsGood();
}

void Task_ValidInput_LastPerformedStringIsGood()
{
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	assert(task1.getLastPerformedAsString() == "3-21-1245");
}

void Task_ValidInput_TimesPerformedIsGood()
{
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	assert(task1.getTimesPerformed() == 4);
}

void Task_ValidInput_VisionIsGood()
{
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	assert(task1.getVision() == "sparkling");
}

void DynamicVectorOverloadedOperator_ValidInput_Works()
{
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "dry", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	DynamicVector<TElem> vector1;
	DynamicVector<TElem> vector2;

	vector1.addElement(task1);
	vector1.addElement(task2);

	vector2 = vector1;

	assert(vector2.getSize() == 2);
}

void FindByTitle_Exists_ReturnTrue()
{
	DynamicVector<TElem> tasks;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	tasks.addElement(task1);
	assert(tasks.findByTitle("clean") == true);
}

void FindByTitle_DoesNotExist_ReturnFalse()
{
	DynamicVector<TElem> tasks{};
	assert(tasks.findByTitle("clean") == false);
}

void AddElement_ValidInput_Added()
{
	DynamicVector<TElem> tasks;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	tasks.addElement(task1);
	assert(tasks.getSize() == 1);
}

void DynamicVector_NoInput_SizeZero()
{
	DynamicVector<TElem> tasks;
	assert(tasks.getSize() == 0);
}

void UpdateElement_ValidInput_Updated()
{
	DynamicVector<TElem> tasks;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "clean", "asfda", Date{03, 21, 1245}, 5, "sparkling" };
	tasks.addElement(task1);
	tasks.updateElement(task2);
	assert(tasks[0].getType() == "asfda");
}

void UpdateElement_InvalidInput_NotUpdated()
{
	DynamicVector<TElem> tasks;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "pay", "asfda", Date{03, 21, 1245}, 5, "sparkling" };
	tasks.addElement(task1);
	tasks.updateElement(task2);
	assert(tasks[0].getType() == "spilled");
}

void DeleteElement_ValidInput_Deleted()
{
	DynamicVector<TElem> tasks;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "pay", "asfda", Date{03, 21, 1245}, 5, "sparkling" };
	tasks.addElement(task1);
	tasks.addElement(task2);
	std::string title = "clean";
	tasks.deleteElement(title);
	assert(tasks.getSize()==1);
}

void DeleteElement_InvalidInput_NotDeleted()
{
	DynamicVector<TElem> tasks;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	tasks.addElement(task1);
	std::string title = "pay";
	tasks.deleteElement(title);
	assert(tasks.getSize() == 1);
}

void AddTask_ValidInput_Added()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	assert(repository.addTask(task1)==true);
}

void AddTask_Duplicate_NotAdded()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "clean", "spill", Date{03, 21, 1245}, 5, "sparkling" };
	repository.addTask(task1);
	assert(repository.addTask(task2)==false);
}

void UpdateTask_ValidInput_Updated()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "clean", "spill", Date{03, 21, 1245}, 5, "sparkling" };
	repository.addTask(task1);
	assert(repository.updateTask(task2) == true);
}

void UpdateTask_NotExisting_NotUpdated()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	Task task2{ "dry", "spill", Date{03, 21, 1245}, 5, "sparkling" };
	repository.addTask(task1);
	assert(repository.updateTask(task2) == false);
}

void DeleteTask_ValidInput_Deleted()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	std::string title = "clean";
	repository.addTask(task1);
	assert(repository.deleteTask(title) == true);
}

void DeleteTask_NotExisting_NotDeleted()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	std::string title = "dry";
	repository.addTask(task1);
	assert(repository.deleteTask(title) == false);
}

void GetAllTasks_ExistsOneTask_ReturnsOne()
{
	Repository repository;
	Task task1{ "clean", "spilled", Date{03, 21, 1245}, 4, "sparkling" };
	repository.addTask(task1);
	DynamicVector<TElem> tasks = repository.getAllTasks();
	assert(tasks.getSize() == 1);
}

void AddTaskService_ValidInput_ReturnTrue()
{
	Repository repository;
	Service service(repository);
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	assert(service.addTaskService(title, type, lastPerformed, timesPerformed, vision) == true);
}

void AddTaskService_Duplicate_ReturnFalse()
{
	Repository repository;
	Service service(repository);
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	service.addTaskService(title, type, lastPerformed, timesPerformed, vision);
	assert(service.addTaskService(title, type, lastPerformed, timesPerformed, vision) == false);
}

void UpdateTaskService_ValidInput_ReturnTrue()
{
	Repository repository;
	Service service(repository);
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	service.addTaskService(title, type, lastPerformed, timesPerformed, vision);
	std::string title2 = "clean";
	std::string type2 = "asd";
	Date lastPerformed2{ 03, 21, 1245 };
	int timesPerformed2 = 5;
	std::string vision2 = "asgasc";
	assert(service.updateTaskService(title2, type2, lastPerformed2, timesPerformed2, vision2) == true);
}

void UpdateTaskService_InvalidInput_ReturnFalse()
{
	Repository repository;
	Service service(repository);
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	service.addTaskService(title, type, lastPerformed, timesPerformed, vision);
	std::string title2 = "dry";
	std::string type2 = "asd";
	Date lastPerformed2{ 03, 21, 1245 };
	int timesPerformed2 = 5;
	std::string vision2 = "asgasc";
	assert(service.updateTaskService(title2, type2, lastPerformed2, timesPerformed2, vision2) == false);
}

void DeleteTaskService_ValidInput_ReturnTrue()
{
	Repository repository;
	Service service(repository);
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	service.addTaskService(title, type, lastPerformed, timesPerformed, vision);
	assert(service.deleteTaskService(title) == true);
}

void DeleteTaskService_InvalidInput_ReturnFalse()
{
	Repository repository;
	Service service(repository);
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	std::string title2 = "dry";
	service.addTaskService(title, type, lastPerformed, timesPerformed, vision);
	assert(service.deleteTaskService(title2) == false);
}

void GetAllTasksService_ExistsOne_ReturnsOne()
{
	Repository repository;
	Service service{ repository };
	std::string title = "clean";
	std::string type = "spilled";
	Date lastPerformed{ 03, 21, 1245 };
	int timesPerformed = 4;
	std::string vision = "sparkling";
	std::string title2 = "dry";
	service.addTaskService(title, type, lastPerformed, timesPerformed, vision);
	DynamicVector<TElem> tasks = service.getAllTasksService();
	assert(tasks.getSize() == 1);
}

void TestAll()
{
	Task_ValidInput_TitleIsGood();
	Task_ValidInput_TypeIsGood();
	Task_ValidInput_LastPerformedIsGood();
	Task_ValidInput_LastPerformedStringIsGood();
	Task_ValidInput_TimesPerformedIsGood();
	Task_ValidInput_VisionIsGood();
	DynamicVectorOverloadedOperator_ValidInput_Works();
	FindByTitle_Exists_ReturnTrue();
	FindByTitle_DoesNotExist_ReturnFalse();
	AddElement_ValidInput_Added();
	DynamicVector_NoInput_SizeZero();
	UpdateElement_ValidInput_Updated();
	UpdateElement_InvalidInput_NotUpdated();
	DeleteElement_ValidInput_Deleted();
	DeleteElement_InvalidInput_NotDeleted();
	AddTask_ValidInput_Added();
	AddTask_Duplicate_NotAdded();
	UpdateTask_ValidInput_Updated();
	UpdateTask_NotExisting_NotUpdated();
	DeleteTask_ValidInput_Deleted();
	DeleteTask_NotExisting_NotDeleted();
	GetAllTasks_ExistsOneTask_ReturnsOne();
	AddTaskService_ValidInput_ReturnTrue();
	AddTaskService_Duplicate_ReturnFalse();
	UpdateTaskService_ValidInput_ReturnTrue();
	UpdateTaskService_InvalidInput_ReturnFalse();
	DeleteTaskService_ValidInput_ReturnTrue();
	DeleteTaskService_InvalidInput_ReturnFalse();
	GetAllTasksService_ExistsOne_ReturnsOne();
}