#pragma once
#include"Task.h"

typedef Task TElem;

template <typename TElem>
class DynamicVector
{
private:
	int capacity, size;
	TElem* elements;
	friend class DynamicVectorIterator;

public:

	/*
		Constructor for the class DynamicVector
		Parameters:
			- capacity : integer
	*/
	DynamicVector(int capacity = 10);

	/*
		Copy function for the class DynamicVector
		Parameters:
			- vector : DynamicVector
	*/
	DynamicVector(const DynamicVector& vector);

	/*
		Function for overloading the operator "=" for class DynamicVector
		Parameters:
			- vector : DynamicVector
		Returns:
			- a reference to a new object of class DynamicVector
	*/
	DynamicVector& operator=(const DynamicVector& vector);

	/*
		Destructor for the class DynamicVector
	*/
	~DynamicVector();

	/*
		Determines if an element is in the list based on the title field
		Parameters:
			- title : std::string
		Returns:
			- true, if it exists
			- false, otherwise
	*/
	bool findByTitle(std::string title);

	/*
		Adds an element to the list
		Parameters:
			- element : TElem
	*/
	void addElement(TElem& element);

	/*
		Updates an element from the list
		Parameters:
			- element : TElem
	*/
	void updateElement(TElem& element);

	/*
		Deletes an element from the list
		Parameters:
			- title : std::string
	*/
	void deleteElement(std::string& title);

	/*
		Getter for the field size
		Returns:
			- the size of the current DynamicVector (integer)
	*/
	int getSize() const;

	/*
		Getter for the element at the specified position
		Parameters:
			- position : integer
		Returns:
			- the element at the specified position in the current DynamicVector (TElem)
	*/
	TElem& operator[](int position);
	
private:

	/*
		Doubles the capacity of the DynamicVector
	*/
	void resize();
};

template<typename TElem>
inline DynamicVector<TElem>::DynamicVector(int capacity)
{
	this->capacity = 10;
	this->elements = new TElem[this->capacity];
	this->size = 0;
}

template<typename TElem>
inline DynamicVector<TElem>::DynamicVector(const DynamicVector& vector)
{
	this->capacity = vector.capacity;
	this->size = vector.size;
	this->elements = new TElem[this->capacity];

	for (int i = 0; i < this->size; i++)
		this->elements[i] = vector.elements[i];
}

template<typename TElem>
inline typename DynamicVector<TElem>::DynamicVector& DynamicVector<TElem>::operator=(const DynamicVector& vector)
{
	if (this == &vector)
		return *this;

	this->capacity = vector.capacity;
	this->size = vector.size;

	delete[] this->elements;

	this->elements = new TElem[this->capacity];

	for (int i = 0; i < this->size; i++)
		this->elements[i] = vector.elements[i];

	return *this;
}

template<typename TElem>
inline DynamicVector<TElem>::~DynamicVector()
{
	delete[] this->elements;
}

template<typename TElem>
inline bool DynamicVector<TElem>::findByTitle(std::string title)
{
	for (int i = 0; i < this->size; i++)
		if (this->elements[i].getTitle() == title)
			return true;
	return false;
}

template<typename TElem>
inline void DynamicVector<TElem>::addElement(TElem& element)
{
	if (this->size == this->capacity)
		this->resize();
	this->elements[this->size++] = element;
}

template<typename TElem>
inline void DynamicVector<TElem>::updateElement(TElem& element)
{
	for (int i = 0; i < this->size; i++)
	{
		if (this->elements[i].getTitle() == element.getTitle())
		{
			this->elements[i].setType(element.getType());
			this->elements[i].setLastPerformed(element.getLastPerformed());
			this->elements[i].setTimesPerformed(element.getTimesPerformed());
			this->elements[i].setVision(element.getVision());
		}
	}
}

template<typename TElem>
inline void DynamicVector<TElem>::deleteElement(std::string& title)
{
	for (int i = 0; i < this->size; i++)
	{
		if (this->elements[i].getTitle() == title)
		{
			this->elements[i] = this->elements[this->size - 1];
			this->size--;
		}
	}
}

template<typename TElem>
inline int DynamicVector<TElem>::getSize() const
{
	return this->size;
}

template<typename TElem>
inline TElem& DynamicVector<TElem>::operator[](int position)
{
	return this->elements[position];
}

template<typename TElem>
inline void DynamicVector<TElem>::resize()
{
	this->capacity *= 2;
	TElem* newElements = new TElem[this->capacity];
	for (int i = 0; i < this->size; i++)
		newElements[i] = this->elements[i];

	delete[] this->elements;

	this->elements = newElements;
}