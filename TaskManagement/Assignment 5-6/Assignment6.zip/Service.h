#pragma once
#include"Repository.h"

class Service
{
private:
	Repository& repository;
	DynamicVector<TElem> personalTaskList;
	DynamicVector<TElem> iterator;
	int currentElement = 0;

public:

	/*
		Constructor for the class Service
		Parameters:
			- repository : Repository
	*/
	Service(Repository& repository) :repository{ repository } {};

	/*
		Service function for adding an element
		Parameters:
			- title : std::string
			- type : std::string
			- lastPerformed : Date
			- timesPerformed : integer
			- vision : std::string
		Returns:
			- true, if it was added
			- false, otherwise
	*/
	bool addTaskService(std::string& title, std::string& type, Date lastPerformed, int timesPerformed, std::string& vision);

	/*
		Service function for updating an element
		Parameters:
			- title : std::string
			- newType : std::string
			- newLastPerformed : Date
			- newTimesPerformed : integer
			- newVision : std::string
		Returns:
			- true, if it was updated
			- false, otherwise
	*/
	bool updateTaskService(std::string& title, std::string& newType, Date newLastPerformed, int newTimesPerformed, std::string& newVision);

	/*
		Service function for deleting an element
		Parameters:
			- title : std::string
		Returns:
			- true, if it was deleted
			- false, otherwise
	*/
	bool deleteTaskService(std::string& title);

	/*
		Service function for getting all the elements
		Returns:
			- the list of elements (DynamicVector)
	*/
	DynamicVector<TElem> getAllTasksService() const;

	void updateIteratorService();

	TElem nextService();

	void saveService();

	DynamicVector<TElem> getMyListService();


};

