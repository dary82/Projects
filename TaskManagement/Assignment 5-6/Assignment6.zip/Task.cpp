#include "Task.h"

Date::Date(int month, int day, int year)
{
	this->month = month;
	this->day = day;
	this->year = year;
}

int Date::getDay() const
{
	return this->day;
}

int Date::getMonth() const
{
	return this->month;
}

int Date::getYear() const
{
	return this->year;
}

Task::Task()
{
	this->title = "";
	this->type = "";
	this->lastPerformed = Date(0, 0, 0);
	this->timesPerformed = 0;
	this->vision = "";
}

Task::Task(const std::string& title, const std::string& type, Date lastPerformed, int timesPerformed, const std::string& vision)
{
	this->title = title;
	this->type = type;
	this->lastPerformed = lastPerformed;
	this->timesPerformed = timesPerformed;
	this->vision = vision;
}

std::string Task::getTitle() const
{
	return this->title;
}

void Task::setTitle(std::string newTitle)
{
	this->title = newTitle;
}

std::string Task::getType() const
{
	return this->type;
}

void Task::setType(std::string newType)
{
	this->type = newType;
}

Date Task::getLastPerformed() const
{
	return this->lastPerformed;
}

std::string Task::getLastPerformedAsString() const
{
	std::string date = std::to_string(this->lastPerformed.getMonth()) + "-" + std::to_string(this->lastPerformed.getDay()) + "-" + std::to_string(this->lastPerformed.getYear());
	return date;
}

void Task::setLastPerformed(Date newLastPerformed)
{
	this->lastPerformed = newLastPerformed;
}

int Task::getTimesPerformed() const
{
	return this->timesPerformed;
}

void Task::setTimesPerformed(int newTimesPerformed)
{
	this->timesPerformed = newTimesPerformed;
}

std::string Task::getVision() const
{
	return this->vision;
}

void Task::setVision(std::string newVision)
{
	this->vision = newVision;
}
