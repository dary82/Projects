#include "UI.h"
#include<iostream>
#include<string>
using namespace std;

void UI::printMenu()
{
	cout << "mode X\n";
	cout << "exit\n";
	cout << "----------------------------------MODE-A-----------------------------------------\n";
	cout << "add title, type, lastPerformed(mm-dd-yyyy), timesPerformed, vision\n";
	cout << "update title, newType, newLastPerformed(dd-mm-yyyy), newTimesPerformed, newVision\n";
	cout << "delete title\n";
	cout << "list\n";
	cout << "---------------------------------------------------------------------------------\n";
	cout << "\n";
	cout << "----------------------------------MODE-B-----------------------------------------\n";
	cout << "next\n";
	cout << "save\n";
	cout << "list type, maximumTimesOperated\n";
	cout << "mylist\n";
	cout << "---------------------------------------------------------------------------------\n";
}

Date UI::createDate(std::string string)
{
	try
	{
		std::string day = string.substr(3, 2);
		std::string month = string.substr(0, 2);
		std::string year = string.substr(6, 4);
		Date newDate{ stoi(month),stoi(day),stoi(year) };
		return newDate;
	}
	catch (exception)
	{
		throw exception("Date must be of format: mm-dd-yyyy");
	}
}

void UI::addTaskUI(std::string parameters[MAX_PARAMETERS])
{
	Date lastPerformed = this->createDate(parameters[PARAMETER_THIRD]);
	bool success = this->service.addTaskService(parameters[PARAMETER_FIRST], parameters[PARAMETER_SECOND], lastPerformed, stoi(parameters[PARAMETER_FOURTH]), parameters[PARAMETER_FIFTH]);
	if (success)
		cout << "Added!\n";
	else
		cout << "No!\n";
}

void UI::updateTaskUI(std::string parameters[MAX_PARAMETERS])
{
	Date lastPerformed = this->createDate(parameters[PARAMETER_THIRD]);
	bool success = this->service.updateTaskService(parameters[PARAMETER_SECOND], parameters[PARAMETER_SECOND], lastPerformed, stoi(parameters[PARAMETER_FOURTH]), parameters[PARAMETER_FIFTH]);
	if (success)
		cout << "Updated!\n";
	else
		cout << "No!\n";
}

void UI::deleteTaskUI(std::string parameters)
{
	bool success = this->service.deleteTaskService(parameters);
	if (success)
		cout << "Deleted!\n";
	else
		cout << "No!\n";
}

void UI::list()
{
	DynamicVector<TElem> tasks = this->service.getAllTasksService();
	int size = tasks.getSize();
	if (size == 0)
		cout << "The list is empty\n";
	else
		for (int i = 0; i < size; i++)
		{
			TElem task = tasks[i];
			cout << task.getTitle() << ", " << task.getType() << ", " << task.getLastPerformedAsString() << ", " << task.getTimesPerformed() << ", " << task.getVision() << "\n";
		}
}

void UI::nextUI()
{
	TElem task = this->service.nextService();
	cout << task.getTitle() << ", " << task.getType() << ", " << task.getLastPerformedAsString() << ", " << task.getTimesPerformed() << ", " << task.getVision() << "\n";
}

void UI::saveUI(std::string title)
{
	this->service.saveService();
}

void UI::listFilteredUI(std::string type, std::string timesPerformed)
{
	if (type == "")
		throw exception("Type must not be empty");
	int maximumTimesPerformed = stoi(timesPerformed);
	DynamicVector<TElem> tasks = this->service.getAllTasksService();
	int size = tasks.getSize();
	if (size == 0)
		cout << "The list is empty\n";
	else
		for (int i = 0; i < size; i++)
		{
			TElem task = tasks[i];
			if (task.getTimesPerformed()<maximumTimesPerformed && task.getType()==type)
				cout << task.getTitle() << ", " << task.getType() << ", " << task.getLastPerformedAsString() << ", " << task.getTimesPerformed() << ", " << task.getVision() << "\n";
		}
}

void UI::mylistUI()
{
	DynamicVector<TElem> tasks = this->service.getMyListService();
	int size = tasks.getSize();
	if (size == 0)
		cout << "The list is empty\n";
	else
		for (int i = 0; i < size; i++)
		{
			TElem task = tasks[i];
			cout << task.getTitle() << ", " << task.getType() << ", " << task.getLastPerformedAsString() << ", " << task.getTimesPerformed() << ", " << task.getVision() << "\n";
		}
}

void UI::runUI()
{
	this->printMenu();
	std::string mode="";
	std::string* parameters = new std::string[MAX_PARAMETERS];
	std::string command;
	std::string userInput;
	int positionOfNextSeparator;
	int parameterCount;
	while (true)
	{ 
		try
		{
			cout << "Command: ";
			getline(cin, userInput);
			parameterCount = 0;
			positionOfNextSeparator = userInput.find(" ");
			if (positionOfNextSeparator == -1)
				command = userInput;
			else
				command = userInput.substr(0, positionOfNextSeparator);
			userInput = userInput.substr(positionOfNextSeparator + 1, userInput.length());
			while (parameterCount < 5)
			{
				positionOfNextSeparator = userInput.find(", ");
				if (positionOfNextSeparator == -1)
				{
					parameters[parameterCount] = userInput;
					break;
				}
				parameters[parameterCount] = userInput.substr(0, positionOfNextSeparator);
				userInput = userInput.substr(positionOfNextSeparator + 2, userInput.length());
				parameterCount++;
			}
			if (command == "exit")
				break;
			if (command == "mode")
			{
				mode = parameters[0];
				if (mode=="B")
					this->service.updateIteratorService();
				if (mode != "A" && mode != "B")
					cout << "Mode needs to be A or B\n";
				continue;
			}
			if (mode != "")
			{
				if (mode == "A")
				{
					if (command == "add")
						this->addTaskUI(parameters);
					else
						if (command == "update")
							this->updateTaskUI(parameters);
						else
							if (command == "delete")
								this->deleteTaskUI(parameters[PARAMETER_FIRST]);
							else
								if (command == "list")
									this->list();
								else
									cout << "Bad command\n";
				}
				else if (mode == "B")
				{
					if (command == "next")
						this->nextUI();
					else
						if (command == "save")
							this->saveUI(parameters[PARAMETER_FIRST]);
						else
							if (command == "list")
								this->listFilteredUI(parameters[PARAMETER_FIRST], parameters[PARAMETER_SECOND]);
							else
								if (command == "mylist")
									this->mylistUI();
								else
									cout << "Bad command\n";
				}
				else
					cout << "Mode needs to be A or B\n";
			}
			else
				cout << "First select a mode (A OR B)\n";
		}
		catch (exception& Exception)
		{
			cout << "Something went wrong: " << Exception.what() << "\n";
		}
	}
}