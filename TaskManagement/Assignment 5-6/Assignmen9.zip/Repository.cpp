#include "Repository.h"

Repository::~Repository()
{
	;
}
