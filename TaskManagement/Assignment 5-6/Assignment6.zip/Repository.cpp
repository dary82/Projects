#include "Repository.h"

bool Repository::addTask(TElem& task)
{
	bool exists = this->tasks.findByTitle(task.getTitle());
	if (!exists)
	{
		this->tasks.addElement(task);
		return true;
	}
	return false;
}

bool Repository::updateTask(TElem& task)
{
	bool exists = this->tasks.findByTitle(task.getTitle());
	if (exists)
	{
		this->tasks.updateElement(task);
		return true;
	}
	return false;
}

bool Repository::deleteTask(std::string& title)
{
	bool exists = this->tasks.findByTitle(title);
	if (exists)
	{
		this->tasks.deleteElement(title);
		return true;
	}
	return false;
}

DynamicVector<TElem> Repository::getAllTasks() const
{
	return this->tasks;
}