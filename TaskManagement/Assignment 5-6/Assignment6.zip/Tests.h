#pragma once

void TestAll();