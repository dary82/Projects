#pragma once
#include"DynamicVector.h"

class Repository
{
private:
	DynamicVector<TElem> tasks;

public:

	/*
		Constructor for the class Repository
	*/
	Repository() {};
	
	/*
		If the element isn't already in the list, it adds it
		Parameters:
			- task : TElem
		Returns:
			- true, if it was added
			- false, otherwise
	*/
	bool addTask(TElem& task);

	/*
		It updates and element if it is in the list
		Parameters:
			- task : TElem
		Returns:
			- true, if it was updated
			- false, otherwise
	*/
	bool updateTask(TElem& task);

	/*
		Deletes an element if it is in a list
		Parameters:
			- title : std::string
		Returns:
			- true, if it was deleted
			- false, otherwise
	*/
	bool deleteTask(std::string& title);

	/*
		Getter for all the elements in the list
		Returns:
			- the list of elements (DynamicVector)
	*/
	DynamicVector<TElem> getAllTasks() const;
};

