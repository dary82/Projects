#pragma once
#include <string>
#include <vector>
#include "Task.h"

std::vector<std::string> tokenize(const std::string& string, char delimiter);

