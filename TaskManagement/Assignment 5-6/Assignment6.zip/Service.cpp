#include "Service.h"

bool Service::addTaskService(std::string& title, std::string& type, Date lastPerformed, int timesPerformed, std::string& vision)
{
	TElem newTask = TElem(title, type, lastPerformed, timesPerformed, vision);
	return this->repository.addTask(newTask);
}

bool Service::updateTaskService(std::string& title, std::string& newType, Date newLastPerformed, int newTimesPerformed, std::string& newVision)
{
	TElem newTask = TElem(title, newType, newLastPerformed, newTimesPerformed, newVision);
	return this->repository.updateTask(newTask);
}

bool Service::deleteTaskService(std::string& title)
{
	return this->repository.deleteTask(title);
}

DynamicVector<TElem> Service::getAllTasksService() const
{
	return this->repository.getAllTasks();
}

void Service::updateIteratorService()
{
	this->iterator = this->getAllTasksService();
	this->currentElement = 0;
}

TElem Service::nextService()
{
	if (this->iterator.getSize() == 0)
		throw std::exception("There is nothing to show");
	if (this->currentElement == this->iterator.getSize() - 1)
		this->currentElement = 0;
	else
		this->currentElement++;
	return this->iterator[this->currentElement];
}

void Service::saveService()
{
	if (this->iterator.getSize() == 0)
		throw std::exception("There is nothing to show");
	TElem task = this->iterator[this->currentElement];
	this->personalTaskList.addElement(task);
}

DynamicVector<TElem> Service::getMyListService()
{
	return this->personalTaskList;
}
