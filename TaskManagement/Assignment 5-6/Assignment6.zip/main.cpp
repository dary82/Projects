#include "UI.h"
#include "Tests.h"
#include <crtdbg.h>

int main()
{
	TestAll();
	Repository repository{};
	Service service{ repository };
	UI ui{service};

	ui.runUI();

	_CrtDumpMemoryLeaks();

	return 0;
}